<?php

error_reporting(0);

require 'database.php';

$db_connect = new DB();
$conn = $db_connect->getInstance();
?>