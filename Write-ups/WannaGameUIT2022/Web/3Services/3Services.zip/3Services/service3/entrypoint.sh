#!/usr/bin/sh
service nginx start
php-fpm