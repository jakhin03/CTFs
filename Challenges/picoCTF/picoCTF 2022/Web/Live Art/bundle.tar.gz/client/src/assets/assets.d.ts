declare module "*.png" {
    export default string;
}